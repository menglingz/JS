function Carousel(obj){
	//合并参数
	Object.assign(this,obj);
	this.count = 0;
	this.timer = null;
	this.init();
}
//重写原型
Carousel.prototype = {
	constructor:Carousel,//指回构造函数
	init:function(){//初始化方法
		this.render();
		this.auto();
		this.bindEvent();
	},
	render:function(){//渲染方法
		this.ul.innerHTML = this.data.map(function(item,ind){
			return `<li index=${ind} class=${ind === 0 ? "active":""}></li>`;
		}).join("");
	},
	auto:function(){//自动播方法
		var that = this;//提前记录this指向
		this.timer = setInterval(function(){
			that.count = ++that.count > that.data.length - 1 ? 0:that.count;
			that.change(that.count); //调用改变图片路径和高亮的方法
		},1000);
	},
	bindEvent:function(){//绑定事件的方法
		var that = this;
		this.box.addEventListener("mouseover",function(){//移入停止播放
			clearInterval(that.timer);
		})
		this.box.addEventListener("mouseout",function(){//移出继续播放
			that.auto();
		})
		this.left.addEventListener("click",function(){//左箭头
			that.count = --that.count < 0 ? that.data.length - 1 : that.count;
			that.change(that.count);
		})
		this.right.addEventListener("click",function(){//右箭头
			that.count = ++that.count > that.data.length - 1 ? 0:that.count;
			that.change(that.count); //调用改变图片路径和高亮的方法
		})
		//事件委托的形式给ul绑定事件
		this.ul.addEventListener("click",function(e){
			var ev = e.target;
			if(ev.nodeName === "LI"){
				that.count = ev.getAttribute("index");
				that.change(that.count);
			}
		})

	},
	change:function(n){//改变图片路径和高亮的公共方法
		this.img.src = this.data[n]; //改变图片路径
		document.querySelector(".active").classList.remove("active");
		this.ul.children[n].classList.add("active");
	}
}
